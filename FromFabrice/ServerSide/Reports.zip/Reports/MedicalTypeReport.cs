using System;
using DevExpress.XtraReports.UI;

namespace ServerSide.Reports
{
    public partial class MedicalTypeReport
    {
        public MedicalTypeReport()
        {
            InitializeComponent();
        }
    }
}
