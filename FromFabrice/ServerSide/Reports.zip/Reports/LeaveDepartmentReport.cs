using System;
using DevExpress.XtraReports.UI;

namespace ServerSide.Reports
{
    public partial class LeaveDepartmentReport
    {
        public LeaveDepartmentReport()
        {
            InitializeComponent();
        }
    }
}
