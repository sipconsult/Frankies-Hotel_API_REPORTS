using System;
using DevExpress.XtraReports.UI;

namespace ServerSide.Reports
{
    public partial class Daily_HME_KPIReport
    {
        public Daily_HME_KPIReport()
        {
            InitializeComponent();
        }
    }
}
