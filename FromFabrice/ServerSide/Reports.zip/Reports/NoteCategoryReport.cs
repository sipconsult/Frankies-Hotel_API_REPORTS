using System;
using DevExpress.XtraReports.UI;

namespace ServerSide.Reports
{
    public partial class NoteCategoryReport
    {
        public NoteCategoryReport()
        {
            InitializeComponent();
        }
    }
}
